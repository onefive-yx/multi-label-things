function [train_data, train_target, test_data, test_target] = preprocess_dataset(dataset_name, train_data, train_target, test_data, test_target)
% 预处理数据
    disp(['start preprocess ', dataset_name, '.............']);
    train_target(train_target == -1) = 0;
    test_target(test_target == -1) = 0;

    data_min = min(train_data);
    data_max = max(train_data);

    % anomaly process
    anomaly_data_idx = data_max == data_min;
    train_data(:, anomaly_data_idx) = [];
    test_data(:, anomaly_data_idx) = [];
    data_max(anomaly_data_idx) = [];
    data_min(anomaly_data_idx) = [];


    
    
    train_data = (train_data - data_min) ./ (data_max - data_min);
    test_data = (test_data - data_min) ./ (data_max - data_min);
    
    disp('-----------------preprocessed train data--------------------');
    disp(train_data(1:3, 1:end));
    disp(train_target(1:3, 1:end));
    disp('------------------------------------------------------------');

    disp('-----------------preprocessed test data---------------------');
    disp(test_data(1:3, 1:end));
    disp(test_target(1:3, 1:end));
    disp('------------------------------------------------------------');

    disp(['end preprocess ', dataset_name, '.............']);
end

