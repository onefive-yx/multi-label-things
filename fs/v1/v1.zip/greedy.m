function [red] = greedy(cm)
% 贪心选择特征子集
% 输入:
%       cm: 一致矩阵
% 输出:
%       red: 选出的特征子集
    [~, m] = size(cm);

    a_indices = 1:m;
    
    red = [];

    z_idxs = all(cm == 0, 2);
    cm(z_idxs, :) = [];

    while ~isempty(cm) && ~isempty(a_indices)
        cols_sum = sum(cm, 1);
        if max(cols_sum) == 0
            break;
        end
        [~, max_idx] = max(cols_sum);
        nz_idxs = cm(:, max_idx) ~= 0;
        cm(nz_idxs, :) = [];
        cm(:, max_idx) = [];
        red = [red, a_indices(max_idx)];
        a_indices(max_idx) = [];
    end
end

