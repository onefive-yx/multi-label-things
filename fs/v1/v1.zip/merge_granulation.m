function [cm] = merge_granulation(data)
% 归并粒化, 适用于多标签的标签空间
% 标签值的域值只有1和0
    [n, m] = size(data);
    gbs = cell(1, 1);
    idx = (1:n)';
    cm = zeros(n, m-1);
    
    for ai = 1:m-1
        d = [data(:, ai), data(:, m), idx];
        d0 = d(d(:, 2) == 0, :);
        d1 = d(d(:, 2) == 1, :);

        [d0_sorted, ~] = sortrows(d0, 1, 'ascend');
        [d1_sorted, ~] = sortrows(d1, 1, 'ascend');

        
        % 删除同一特征下, 不同标签值的相同特征值
        common_elems = intersect(d0_sorted(:, 1), d1_sorted(:, 1));
        d0_sorted = d0_sorted(~ismember(d0_sorted(:, 1), common_elems), :);
        d1_sorted = d1_sorted(~ismember(d1_sorted(:, 1), common_elems), :);

        d0_len = size(d0_sorted, 1);
        d1_len = size(d1_sorted, 1);
        i1 = 1;
        i2 = 1;
        j1 = 1;
        j2 = 1;
        k = 1;
        while i1 <= d0_len && j1 <= d1_len
            while i1 <= d0_len && j1 <= d1_len && d0_sorted(i1, 1) < d1_sorted(j1, 1)
                %
                i1 = i1 + 1;
            end
            gbs{k} = d0_sorted(i2:i1-1, :);
            cm(gbs{k}(:, 3)', ai) = length(i2:i1-1) / length(d0);
            k = k + 1;
            i2 = i1;

            if i1 > d0_len || j1 > d1_len
                break;
            end

            while i1 <= d0_len && j1 <= d1_len && d0_sorted(i1, 1) > d1_sorted(j1, 1)
                %
                j1 = j1 + 1;
            end
            gbs{k} = d1_sorted(j2:j1-1, :);
            cm(gbs{k}(:, 3)', ai) = length(j2:j1-1) / length(d1);
            k = k + 1;
            j2 = j1; 
        end

        if i1 <= d0_len
            gbs{k} = d0_sorted(i2:d0_len, :);
            cm(gbs{k}(:, 3)', ai) = length(i2:d0_len) / length(d0);
        end
        if j1 <= d1_len
            gbs{k} = d1_sorted(j2:d1_len, :);
            cm(gbs{k}(:, 3)', ai) = length(j2:d1_len) / length(d1);
        end
    end

end

