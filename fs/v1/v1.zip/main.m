clear;
clc;

% 75 个 multi-label datasets
datasets = {'20NG', '3sources_bbc1000', '3sources_guardian1000', ...
    '3sources_inter3000', '3sources_reuters1000', 'Arts', 'Bibtex', 'Birds', ...
    'Bookmarks', 'Business', 'CAL500', 'CHD_49', 'Computers', 'Corel16k001', 'Corel16k002', ...
    'Corel16k003', 'Corel16k004', 'Corel16k005', 'Corel16k006', 'Corel16k007', 'Corel16k008', ...
    'Corel16k009', 'Corel16k010', 'Corel5k', 'Delicious', 'Education', 'Emotions', 'Enron', ...
    'Entertainment', 'EukaryoteGO', 'EukaryotePseAAC', 'Eurlex(ev)', 'Flags', 'Foodtruck', ...
    'Genbase', 'GnegativeGO', 'GnegativePseAAC', 'GpositiveGO', 'GpositivePseAAC', 'Health', ...
    'HumanGO', 'HumanPseAAC', 'Image', 'Imdb', 'Langlog', 'Mediamill', 'Medical', 'Oshumed', ...
    'PlantGO', 'PlantPseAAC', 'rcv1subset1', 'rcv1subset2', 'rcv1subset3', ...
    'rcv1subset4', 'rcv1subset5', 'Recreation', 'Reference', 'Scene', ...
    'Science', 'Slashdot', 'Social', 'Society', 'Stackex_chemistry', 'Stackex_chess', ...
    'Stackex_coffee', 'Stackex_cooking', 'Stackex_cs', 'Stackex_philosophy', 'tmc2007', ...
    'tmc2007-500', 'VirusGO', 'VirusPseAAC', 'Water-quality', 'Yeast', 'Yelp'};

large_dts = {'Bookmarks', 'Eurlex(ev)', 'Imdb', 'tmc2007', 'Mediamill' ,'rcv1subset1', ...
    'rcv1subset2', 'rcv1subset3', 'rcv1subset4', 'rcv1subset5'};



Yahoos = {'Arts', 'Business','Computers', 'Education', 'Entertainment', 'Recreation', ...
    'Reference', 'Science', 'Social', 'Society', 'Health'};

datasets_basepath = 'datasets\datasets_v2\';
result_basepath = 'codes\v2\results_2025_03_01_1\'; % save result path

% result table
table_header = {'dataset', 'train_size', 'test_size', 'feature_size', 'label_size', ...
    'selected_percent','selected_features_num', 'Hamming Loss', 'Ranking Loss', ...
    'One Error', 'Coverage', 'Average Precision', 'Macro-F1', 'Micro-F1', 'Subset Accuracy','select_time', 'alpha', 'selected_features'};
result_table = cell(128, length(table_header));
result_table(1, :) = table_header;

% 遍历每一个数据集
for dataset_idx = 74:length(datasets)
    current_result_table = result_table;
  
    dataset = datasets{dataset_idx};
    fprintf("%d --- %s reading: \n\n", dataset_idx, dataset);

    read_flag = true;

    if ismember(dataset, large_dts)
        continue;
    end

    %% 读取数据集, 不同读取方式因为数据格式不同
    if read_flag && ~ismember(dataset, large_dts) && strcmp(dataset, 'Eurlex(ev)')
        train_data_path = [datasets_basepath, dataset, '\', dataset, '_train_data.mat'];
        train_target_path = [datasets_basepath, dataset, '\', dataset, '_train_target.mat'];
        test_data_path = [datasets_basepath, dataset, '\', dataset, '_test_data.mat'];
        test_target_path = [datasets_basepath, dataset, '\', dataset, '_test_target.mat'];

        load(train_data_path);
        load(train_target_path);
        load(test_data_path);
        load(test_target_path);
        read_flag = false;
    end

    if read_flag && ~ismember(dataset, large_dts) && ismember(dataset, Yahoos)
        train_path = [datasets_basepath, dataset, '\', dataset, '_data.mat'];
        load(train_path);
        train_data = cell2mat(bags);
        train_target = targets';
        train_target(train_target == -1) = 0;

        test_path = [datasets_basepath, dataset, '\', dataset, '_test.mat'];
        load(test_path);
        test_data = cell2mat(bags);
        test_target = targets';
        test_target(test_target == -1) = 0;
        read_flag = false;
    end

    if read_flag && ~ismember(dataset, large_dts) 
        train_data_path = [datasets_basepath, dataset, '\', dataset, '-train-attributes.csv'];
        train_target_path = [datasets_basepath, dataset, '\', dataset, '-train-labels.csv'];
        test_data_path = [datasets_basepath, dataset, '\', dataset, '-test-attributes.csv'];
        test_target_path = [datasets_basepath, dataset, '\', dataset, '-test-labels.csv'];

        origin_train_data = readtable(train_data_path, 'ReadVariableNames',true);
        origin_train_target = readtable(train_target_path, 'ReadVariableNames',true);
        origin_test_data = readtable(test_data_path, 'ReadVariableNames',true);
        origin_test_target = readtable(test_target_path, 'ReadVariableNames',true);

        train_data = table2array(origin_train_data);
        train_target = table2array(origin_train_target);
        test_data = table2array(origin_test_data);
        test_target = table2array(origin_test_target);
        read_flag = false;
    end
    

    %% 统一预处理数据
    % 预处理数据(ppcd == preprocessed)
	[ppcd_train_data, ppcd_train_target, ppcd_test_data, ppcd_test_target] = preprocess_dataset(dataset, ...
        train_data, train_target, test_data, test_target);

        
    %% 添加特征选择算法入口函数的路径, 以及算法所需参数的设置
    addpath('codes\v2\');
    %
    %
    %
    

    %% 执行算法, 运行超过1000s, 则停止运行
    % max_time = 1000;
    alphas = 0.0:0.01:0.99;
    
    tic;
    targets_sum = sum(ppcd_train_target, 1);

    %[idxs, ~] = kmeans(train_data, 10, 'EmptyAction', 'singleton');
    distances = pdist(ppcd_train_data);
    linkage_matrix = linkage(distances, 'ward');
    idxs = cluster(linkage_matrix, 'maxclust', 10);
    st_1 = toc;
    
    
    for i = 1:length(alphas)
    fprintf('alpha: %d --- \n', i);

    tic;
    [result] = v2(ppcd_train_data, ppcd_train_target, targets_sum, idxs, alphas(i));
    st_2 = toc;
    select_time = st_1 + st_2;


    %%
    % 处理你的结果, 得到特征子集
    red = [];
    for ridx = 1:length(result)
        red = union(red, result{ridx});
    end


    %%
    % 算法评估
    p = '\';
    
    % 评估(mlfs == multi-label feature selection)
	[Hamming_Loss, Ranking_Loss, One_Error, Coverage, Average_Precision, Macro_F1, Micro_F1, Subset_Accuracy] = mlfs_evaluate(ppcd_train_data, ...
           ppcd_train_target, ppcd_test_data, ppcd_test_target, red);
    
    current_result = {dataset, size(ppcd_train_data, 1), size(ppcd_test_data, 1), size(ppcd_train_data, 2), ...
           size(ppcd_train_target, 2), p, length(red), Hamming_Loss, Ranking_Loss, ...
           One_Error, Coverage, Average_Precision, Macro_F1, Micro_F1, Subset_Accuracy, select_time, alphas(i), red};
    current_result_table(1+i, :) = current_result;
    
    end

    %%
	% 写入结果到csv文件中
	current_result_path = [result_basepath, dataset, '_result.csv'];
	writecell(current_result_table, current_result_path);

end

