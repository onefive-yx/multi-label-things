function [HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Macro_F1, Micro_F1, Subset_Accuracy] = mlfs_evaluate(train_data, train_target, test_data, test_target, selected_features)
% 评估多标签特征选择算法
    addpath('codes\classifier\ML_KNN\')
    % 将入参处理为分类器所需的数据格式
    train_data = train_data(:, selected_features);
    test_data = test_data(:, selected_features);
    train_target(train_target == 0) = -1;
    test_target(test_target == 0) = -1;
    
    
    % Set parameters for the MLKNN algorithm
    % Set the number of nearest neighbors considered to 10 and the smoothing parameter to 1
    Num=10;
    Smooth=1;

    % Calling the main functions
    % Invoking the training procedure
    [Prior, PriorN, Cond, CondN]=MLKNN_train(train_data, train_target', Num, Smooth);
    % Performing the test procedure
    [HammingLoss, RankingLoss, OneError, Coverage, Average_Precision, Macro_F1, Micro_F1, Subset_Accuracy, ~, ~]=MLKNN_test(train_data, ...
        train_target', test_data, test_target', Num, Prior, PriorN, Cond, CondN);
end

