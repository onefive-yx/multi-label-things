function [reds] = v2(train_data, train_target, targets_sum, idxs, alpha)
% 基于模糊粒化的多标签特征选择算法
% 2025-03-01 对样本进行聚类, 再对特征打分
    [n, m] = size(train_data);
    [~, c] = size(train_target);


    %features_score = [];
    %lf_cm = zeros(c, m);
    reds = cell(c, 1);
    %bads = cell(c, 1);
    
    disp('---------------------start v2---------------------');
    for li = 1:c
        if targets_sum(li) == 0 || targets_sum(li) == n
            continue;
        end
        cm = zeros(n, m);
        
        for idx = 1:10
            current_idxs = find(idxs == idx);
            current_train_data = train_data(current_idxs, :);
            current_train_target = train_target(current_idxs, :);
            cm(current_idxs, :) = merge_granulation([current_train_data, current_train_target(:, li)]);
        end
        
        %cm = merge_granulation([train_data, train_target(:, li)]);
        %reds{li} = greedy_v4(cm);
        % 2025-02-19
        %
        cm(cm <= alpha) = 0;
        %
        % 2025-02-19
        %[reds{li}, bads{li}] = greedy_v2(cm);
        
        %features_score = union(features_score, red);
        %lf_cm(li, red) = 1;
        reds{li} = greedy(cm);
        disp(li);
    end
    %features_score = find(sum(lf_cm, 1)~=0);
    disp('---------------------end v2----------------------');
end

